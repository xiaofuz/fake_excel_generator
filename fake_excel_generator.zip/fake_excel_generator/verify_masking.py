
import os
import sys
import django

# Setup Django environment
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'fake_excel_generator.settings')
django.setup()

from generator.utils import (
    generate_customer_data,
    generate_employee_archive_data,
    generate_supplier_info_data
)

def check_masking(data, type_name):
    print(f"--- Checking {type_name} ---")
    header = data[0]
    first_row = data[1]
    
    for idx, col_name in enumerate(header):
        value = first_row[idx]
        print(f"{col_name}: {value}")

print("Verifying data masking...")

# Check Customer Data (Name, Phone, Email, Address)
customer_data = generate_customer_data(1)
check_masking(customer_data, "Customer Data")

# Check Employee Data (Name, ID Card, Phone, Address, Bank Card if present)
employee_data = generate_employee_archive_data(1)
check_masking(employee_data, "Employee Data")

# Check Supplier Data (Contact Name, Phone)
supplier_data = generate_supplier_info_data(1)
check_masking(supplier_data, "Supplier Data")
