from django.db import models
from django.utils import timezone

class Message(models.Model):
    content = models.TextField(verbose_name='留言内容')
    created_at = models.DateTimeField(default=timezone.now, verbose_name='创建时间')
    ip_address = models.CharField(max_length=50, verbose_name='用户IP地址')
    likes = models.IntegerField(default=0, verbose_name='点赞数')
    
    class Meta:
        verbose_name = '留言'
        verbose_name_plural = '留言'
        ordering = ['-created_at']
    
    def __str__(self):
        return f'{self.content[:50]}...' if len(self.content) > 50 else self.content
