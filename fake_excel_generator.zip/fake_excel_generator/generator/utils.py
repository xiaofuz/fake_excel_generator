import openpyxl
from faker import Faker
import random
from io import BytesIO
import datetime

fake = Faker('zh_CN')

def mask_name(name):
    """Mask name: 张三 -> 张*三, 李四 -> 李*"""
    if not name: return name
    if len(name) == 2:
        return name[0] + '*'
    elif len(name) > 2:
        return name[0] + '*' * (len(name) - 2) + name[-1]
    return name

def mask_phone(phone):
    """Mask phone: 13812345678 -> 138****5678"""
    if not phone or len(phone) < 7: return phone
    return phone[:3] + '****' + phone[-4:]

def mask_id_card(id_card):
    """Mask ID card: 110101199001011234 -> 110101********1234"""
    if not id_card or len(id_card) < 10: return id_card
    return id_card[:6] + '********' + id_card[-4:]

def mask_email(email):
    """Mask email: abc@example.com -> ab****@example.com"""
    if not email or '@' not in email: return email
    user, domain = email.split('@')
    if len(user) <= 1: return email
    return user[:2] + '****@' + domain

def mask_address(addr):
    """Mask address: preserve first 6 chars"""
    if not addr or len(addr) < 6: return addr
    return addr[:6] + '******'

def mask_bank_card(card):
    """Mask bank card: 622202...1234 -> 6222********1234"""
    if not card or len(card) < 8: return card
    return card[:4] + '********' + card[-4:]

TYPES = {
    'order': '订单管理表',
    'customer': '客户信息登记表',
    'finance': '财务对账表',
    'sales': '销售统计表',
    'inventory': '库存管理表',
    'shipping': '发货记录表',
    'attendance': '员工考勤表',
    'quote': '报价单',
    'purchase': '采购清单',
    'summary': '数据汇总表',
    'raw_material': '原材料库存明细表',
    'production_plan': '生产计划排产表',
    'material_req': '车间领料申请单',
    'production_track': '生产进度跟踪表',
    'maintenance': '设备维修保养记录表',
    'finished_inspection': '成品入库检验单',
    'piecework_wage': '计件工资核算表',
    'outsourcing': '委外加工管理表',
    'ecommerce_inventory': '电商平台库存同步表',
    'daily_order_summary': '每日订单汇总表',
    'return_refund': '退货/退款跟进表',
    'replacement': '补发货记录表',
    'promotion_review': '促销活动复盘表',
    'logistics_monitor': '物流单号异常监控表',
    'packing_progress': '打包/打单进度表',
    'ads_data': '直通车/广告投放数据表',
    'bill_reconciliation': '平台账单差异对账表',
    'supplier_info': '供应商信息库',
    'inbound_acceptance': '入库验收单',
    'supplier_eval': '供应商评价表',
    'expense_reimbursement': '费用报销明细表',
    'cash_flow': '现金流量表',
    'crm_followup': '客户跟进记录表',
    'customer_complaint': '客户投诉建议表',
    'fixed_asset': '固定资产登记表',
    'employee_archive': '员工档案表',
}

def generate_order_data(rows):
    data = [['订单编号', '客户名称', '下单日期', '商品名称', '数量', '单价', '总金额', '订单状态', '支付方式']]
    for _ in range(rows):
        qty = random.randint(1, 100)
        price = round(random.uniform(10, 1000), 2)
        data.append([
            f"ORD{fake.unique.random_number(digits=10)}",
            mask_name(fake.name()),
            fake.date_this_year().strftime('%Y-%m-%d'),
            fake.word() + '商品',
            qty,
            price,
            round(qty * price, 2),
            random.choice(['待支付', '已支付', '已发货', '已完成', '已取消']),
            random.choice(['微信', '支付宝', '银行卡', '现金'])
        ])
    return data

def generate_customer_data(rows):
    data = [['客户ID', '姓名', '性别', '联系电话', '电子邮箱', '地址', '注册日期', '会员等级']]
    for _ in range(rows):
        data.append([
            f"CUST{fake.unique.random_number(digits=8)}",
            mask_name(fake.name()),
            random.choice(['男', '女']),
            mask_phone(fake.phone_number()),
            mask_email(fake.email()),
            mask_address(fake.address()),
            fake.date_this_decade().strftime('%Y-%m-%d'),
            random.choice(['普通会员', '银卡会员', '金卡会员', '钻石会员'])
        ])
    return data

def generate_finance_data(rows):
    data = [['流水号', '交易日期', '交易类型', '对方账户', '交易金额', '余额', '备注']]
    balance = 100000.00
    for _ in range(rows):
        amount = round(random.uniform(-5000, 10000), 2)
        balance += amount
        data.append([
            f"FIN{fake.unique.random_number(digits=12)}",
            fake.date_this_year().strftime('%Y-%m-%d'),
            random.choice(['收入', '支出', '转账', '提现']),
            fake.company(),
            amount,
            round(balance, 2),
            fake.sentence()
        ])
    return data

def generate_sales_data(rows):
    data = [['销售单号', '销售日期', '销售员', '区域', '产品名称', '销售数量', '销售金额', '毛利']]
    for _ in range(rows):
        qty = random.randint(1, 500)
        amount = round(random.uniform(100, 5000), 2)
        data.append([
            f"SALE{fake.unique.random_number(digits=10)}",
            fake.date_this_year().strftime('%Y-%m-%d'),
            mask_name(fake.name()),
            random.choice(['华东区', '华南区', '华北区', '西南区', '西北区']),
            fake.word() + '产品',
            qty,
            amount,
            round(amount * random.uniform(0.1, 0.4), 2)
        ])
    return data

def generate_inventory_data(rows):
    data = [['商品编码', '商品名称', '规格型号', '单位', '当前库存', '安全库存', '入库单价', '仓库位置']]
    for _ in range(rows):
        data.append([
            f"PROD{fake.unique.random_number(digits=6)}",
            fake.word() + '配件',
            f"{random.choice(['X', 'L', 'M', 'S'])}-{random.randint(100, 999)}",
            random.choice(['个', '件', '箱', '套']),
            random.randint(0, 1000),
            random.randint(10, 100),
            round(random.uniform(5, 500), 2),
            f"{random.choice(['A', 'B', 'C'])}区-{random.randint(1, 20)}架"
        ])
    return data

def generate_shipping_data(rows):
    data = [['发货单号', '订单编号', '发货日期', '收货人', '收货电话', '收货地址', '物流公司', '物流单号']]
    for _ in range(rows):
        data.append([
            f"SHIP{fake.unique.random_number(digits=10)}",
            f"ORD{fake.unique.random_number(digits=10)}",
            fake.date_this_year().strftime('%Y-%m-%d'),
            mask_name(fake.name()),
            mask_phone(fake.phone_number()),
            mask_address(fake.address()),
            random.choice(['顺丰', '圆通', '中通', '韵达', 'EMS']),
            f"LOG{fake.unique.random_number(digits=12)}"
        ])
    return data

def generate_attendance_data(rows):
    data = [['员工工号', '姓名', '部门', '考勤日期', '上班打卡', '下班打卡', '考勤状态']]
    for _ in range(rows):
        date = fake.date_this_month()
        status = random.choice(['正常', '迟到', '早退', '缺卡', '请假'])
        start_time = '09:00' if status == '正常' else f"09:{random.randint(1, 59):02d}"
        end_time = '18:00' if status == '正常' else f"17:{random.randint(1, 59):02d}"
        
        if status == '缺卡':
            start_time = ''
            end_time = ''
        elif status == '请假':
            start_time = '请假'
            end_time = '请假'

        data.append([
            f"EMP{fake.unique.random_number(digits=5)}",
            mask_name(fake.name()),
            random.choice(['技术部', '人事部', '财务部', '市场部', '销售部']),
            date.strftime('%Y-%m-%d'),
            start_time,
            end_time,
            status
        ])
    return data

def generate_quote_data(rows):
    data = [['报价单号', '客户名称', '报价日期', '项目名称', '预估工期(天)', '报价金额', '有效期至']]
    for _ in range(rows):
        date = fake.date_this_year()
        valid_until = date + datetime.timedelta(days=30)
        data.append([
            f"QT{fake.unique.random_number(digits=8)}",
            fake.company(),
            date.strftime('%Y-%m-%d'),
            fake.word() + '项目',
            random.randint(7, 90),
            round(random.uniform(5000, 100000), 2),
            valid_until.strftime('%Y-%m-%d')
        ])
    return data

def generate_purchase_data(rows):
    data = [['采购单号', '供应商', '采购日期', '物料名称', '采购数量', '单价', '总价', '预计到货日期']]
    for _ in range(rows):
        qty = random.randint(10, 1000)
        price = round(random.uniform(1, 200), 2)
        date = fake.date_this_year()
        arrival = date + datetime.timedelta(days=random.randint(3, 15))
        data.append([
            f"PUR{fake.unique.random_number(digits=8)}",
            fake.company(),
            date.strftime('%Y-%m-%d'),
            fake.word() + '原料',
            qty,
            price,
            round(qty * price, 2),
            arrival.strftime('%Y-%m-%d')
        ])
    return data

def generate_summary_data(rows):
    data = [['部门', '月份', '总收入', '总支出', '净利润', '员工人数', '新客增长率']]
    depts = ['技术部', '人事部', '财务部', '市场部', '销售部']
    for _ in range(rows):
        income = round(random.uniform(50000, 500000), 2)
        expense = round(random.uniform(20000, 300000), 2)
        data.append([
            random.choice(depts),
            fake.month_name(),
            income,
            expense,
            round(income - expense, 2),
            random.randint(5, 50),
            f"{random.uniform(-5, 20):.2f}%"
        ])
    return data

def generate_raw_material_data(rows):
    data = [['物料编码', '物料名称', '规格型号', '材质', '库存数量', '单位', '存放库位', '最近入库日期']]
    for _ in range(rows):
        data.append([
            f"MAT{fake.unique.random_number(digits=6)}",
            fake.word() + '原料',
            f"{random.randint(1,100)}mm*{random.randint(1,100)}mm",
            random.choice(['钢', '铁', '塑料', '木材', '铝合金']),
            random.randint(100, 10000),
            random.choice(['KG', '吨', '米', '平方米']),
            f"{random.choice(['A', 'B', 'C'])}库-{random.randint(1, 50)}号",
            fake.date_this_year().strftime('%Y-%m-%d')
        ])
    return data

def generate_production_plan_data(rows):
    data = [['计划单号', '产品名称', '计划数量', '开始日期', '结束日期', '生产线', '负责人', '状态']]
    for _ in range(rows):
        start_date = fake.date_this_month()
        end_date = start_date + datetime.timedelta(days=random.randint(1, 10))
        data.append([
            f"PLAN{fake.unique.random_number(digits=8)}",
            fake.word() + '成品',
            random.randint(100, 5000),
            start_date.strftime('%Y-%m-%d'),
            end_date.strftime('%Y-%m-%d'),
            f"产线{random.randint(1, 5)}",
            mask_name(fake.name()),
            random.choice(['未开始', '进行中', '已完成', '延期'])
        ])
    return data

def generate_material_req_data(rows):
    data = [['领料单号', '领料部门', '领料日期', '物料编码', '物料名称', '申请数量', '用途', '审批状态']]
    for _ in range(rows):
        data.append([
            f"REQ{fake.unique.random_number(digits=8)}",
            random.choice(['生产一部', '生产二部', '装配车间', '包装车间']),
            fake.date_this_month().strftime('%Y-%m-%d'),
            f"MAT{fake.random_number(digits=6)}",
            fake.word() + '原料',
            random.randint(10, 500),
            random.choice(['正常生产', '试样', '返工']),
            random.choice(['待审批', '已批准', '已驳回'])
        ])
    return data

def generate_production_track_data(rows):
    data = [['工单号', '产品名称', '工序', '派工数量', '完工数量', '不良数量', '作业人员', '记录时间']]
    for _ in range(rows):
        qty = random.randint(50, 200)
        done = random.randint(0, qty)
        bad = random.randint(0, int(done * 0.1)) if done > 0 else 0
        data.append([
            f"WO{fake.unique.random_number(digits=8)}",
            fake.word() + '零件',
            random.choice(['下料', '车削', '铣削', '打磨', '组装', '包装']),
            qty,
            done,
            bad,
            mask_name(fake.name()),
            fake.date_time_this_month().strftime('%Y-%m-%d %H:%M:%S')
        ])
    return data

def generate_maintenance_data(rows):
    data = [['设备编号', '设备名称', '维修/保养', '开始时间', '结束时间', '故障描述/保养内容', '维修人员', '费用']]
    for _ in range(rows):
        start_time = fake.date_time_this_year()
        end_time = start_time + datetime.timedelta(hours=random.randint(1, 48))
        data.append([
            f"EQ{fake.unique.random_number(digits=4)}",
            fake.word() + '机床',
            random.choice(['维修', '保养']),
            start_time.strftime('%Y-%m-%d %H:%M'),
            end_time.strftime('%Y-%m-%d %H:%M'),
            fake.sentence(),
            mask_name(fake.name()),
            round(random.uniform(0, 5000), 2)
        ])
    return data

def generate_finished_inspection_data(rows):
    data = [['检验单号', '生产批号', '产品名称', '送检数量', '合格数量', '不合格数量', '合格率', '检验员', '检验结果']]
    for _ in range(rows):
        total = random.randint(100, 1000)
        passed = int(total * random.uniform(0.9, 1.0))
        failed = total - passed
        rate = f"{(passed/total)*100:.2f}%"
        data.append([
            f"INS{fake.unique.random_number(digits=8)}",
            f"BATCH{fake.random_number(digits=6)}",
            fake.word() + '成品',
            total,
            passed,
            failed,
            rate,
            mask_name(fake.name()),
            '合格' if failed == 0 else '不合格' if failed > total * 0.05 else '让步接收'
        ])
    return data

def generate_piecework_wage_data(rows):
    data = [['员工工号', '姓名', '日期', '工序', '计件单价', '完成数量', '计件工资', '质检扣款', '实发工资']]
    for _ in range(rows):
        price = round(random.uniform(0.1, 5.0), 2)
        qty = random.randint(100, 2000)
        wage = round(price * qty, 2)
        deduction = round(wage * random.uniform(0, 0.05), 2)
        data.append([
            f"EMP{fake.random_number(digits=5)}",
            mask_name(fake.name()),
            fake.date_this_month().strftime('%Y-%m-%d'),
            random.choice(['工序A', '工序B', '工序C']),
            price,
            qty,
            wage,
            deduction,
            round(wage - deduction, 2)
        ])
    return data

def generate_outsourcing_data(rows):
    data = [['委外单号', '加工商', '产品名称', '发出数量', '发出日期', '应回日期', '实回数量', '加工费', '状态']]
    for _ in range(rows):
        qty = random.randint(100, 1000)
        send_date = fake.date_this_year()
        return_date = send_date + datetime.timedelta(days=random.randint(5, 20))
        data.append([
            f"OUT{fake.unique.random_number(digits=8)}",
            fake.company(),
            fake.word() + '半成品',
            qty,
            send_date.strftime('%Y-%m-%d'),
            return_date.strftime('%Y-%m-%d'),
            random.choice([qty, qty-random.randint(1, 10), 0]),
            round(random.uniform(1000, 50000), 2),
            random.choice(['进行中', '已完工', '延期'])
        ])
    return data

def generate_ecommerce_inventory_data(rows):
    data = [['SKU', '商品名称', '平台', '本地库存', '平台库存', '占用库存', '可用库存', '同步状态', '最后同步时间']]
    for _ in range(rows):
        local_stock = random.randint(100, 1000)
        platform_stock = local_stock - random.randint(0, 20)
        data.append([
            f"SKU{fake.unique.random_number(digits=6)}",
            fake.word() + '商品',
            random.choice(['淘宝', '京东', '拼多多', '抖音', '亚马逊']),
            local_stock,
            platform_stock,
            random.randint(0, 50),
            local_stock - random.randint(0, 50),
            random.choice(['成功', '失败', '同步中']),
            fake.date_time_this_day().strftime('%Y-%m-%d %H:%M:%S')
        ])
    return data

def generate_daily_order_summary_data(rows):
    data = [['日期', '平台', '订单总数', '有效订单', '取消订单', '总金额', '客单价', '转化率']]
    for _ in range(rows):
        total = random.randint(100, 5000)
        valid = int(total * random.uniform(0.8, 0.95))
        amount = round(valid * random.uniform(50, 200), 2)
        data.append([
            fake.date_this_year().strftime('%Y-%m-%d'),
            random.choice(['淘宝', '京东', '拼多多', '自营商城']),
            total,
            valid,
            total - valid,
            amount,
            round(amount / valid, 2),
            f"{random.uniform(1.0, 5.0):.2f}%"
        ])
    return data

def generate_return_refund_data(rows):
    data = [['售后单号', '关联订单', '申请日期', '退款金额', '退款原因', '退货物流', '处理状态', '处理人']]
    for _ in range(rows):
        data.append([
            f"REF{fake.unique.random_number(digits=10)}",
            f"ORD{fake.unique.random_number(digits=10)}",
            fake.date_this_year().strftime('%Y-%m-%d'),
            round(random.uniform(10, 1000), 2),
            random.choice(['质量问题', '拍错/多拍', '不喜欢/不想要', '物流慢', '缺货']),
            random.choice(['顺丰', '圆通', '无需退货']),
            random.choice(['待审核', '待退货', '待退款', '已完成', '已拒绝']),
            mask_name(fake.name())
        ])
    return data

def generate_replacement_data(rows):
    data = [['补发单号', '原订单号', '收货人', '联系电话', '地址', '补发原因', '补发商品', '物流单号']]
    for _ in range(rows):
        data.append([
            f"REP{fake.unique.random_number(digits=10)}",
            f"ORD{fake.unique.random_number(digits=10)}",
            mask_name(fake.name()),
            mask_phone(fake.phone_number()),
            mask_address(fake.address()),
            random.choice(['破损补寄', '漏发补寄', '赠品补发']),
            fake.word() + '商品',
            f"LOG{fake.unique.random_number(digits=12)}"
        ])
    return data

def generate_promotion_review_data(rows):
    data = [['活动名称', '开始时间', '结束时间', '投入成本', '产出金额', 'ROI', '新客数', '参与人数']]
    for _ in range(rows):
        cost = random.uniform(1000, 50000)
        revenue = cost * random.uniform(0.5, 5.0)
        data.append([
            fake.word() + '大促',
            fake.date_this_year().strftime('%Y-%m-%d'),
            fake.date_this_year().strftime('%Y-%m-%d'),
            round(cost, 2),
            round(revenue, 2),
            f"{revenue/cost:.2f}",
            random.randint(100, 5000),
            random.randint(1000, 50000)
        ])
    return data

def generate_logistics_monitor_data(rows):
    data = [['物流单号', '物流公司', '发货日期', '最后更新时间', '当前状态', '异常原因', '跟进记录']]
    for _ in range(rows):
        data.append([
            f"LOG{fake.unique.random_number(digits=12)}",
            random.choice(['顺丰', '圆通', '中通', '韵达']),
            fake.date_this_month().strftime('%Y-%m-%d'),
            fake.date_time_this_month().strftime('%Y-%m-%d %H:%M'),
            random.choice(['运输中', '派送中', '异常']),
            random.choice(['超时未更新', '地址不详', '拒收', '丢件', '无']),
            fake.sentence()
        ])
    return data

def generate_packing_progress_data(rows):
    data = [['批次号', '订单总数', '已打单', '已配货', '已打包', '已揽收', '操作员', '当前进度']]
    for _ in range(rows):
        total = random.randint(100, 1000)
        packed = random.randint(0, total)
        data.append([
            f"BATCH{fake.unique.random_number(digits=8)}",
            total,
            total,
            random.randint(packed, total),
            packed,
            random.randint(0, packed),
            mask_name(fake.name()),
            f"{(packed/total)*100:.1f}%"
        ])
    return data

def generate_ads_data(rows):
    data = [['计划名称', '投放平台', '日期', '展现量', '点击量', '点击率', '花费', '转化单数', 'ROI']]
    for _ in range(rows):
        impressions = random.randint(1000, 100000)
        clicks = int(impressions * random.uniform(0.01, 0.05))
        cost = round(clicks * random.uniform(0.5, 5.0), 2)
        orders = int(clicks * random.uniform(0.05, 0.2))
        revenue = orders * random.uniform(50, 200)
        data.append([
            fake.word() + '推广计划',
            random.choice(['直通车', '引力魔方', '万相台', '巨量引擎']),
            fake.date_this_month().strftime('%Y-%m-%d'),
            impressions,
            clicks,
            f"{(clicks/impressions)*100:.2f}%",
            cost,
            orders,
            f"{revenue/cost:.2f}" if cost > 0 else "0"
        ])
    return data

def generate_bill_reconciliation_data(rows):
    data = [['账单日期', '订单号', '平台金额', '系统金额', '差异金额', '差异原因', '对账状态']]
    for _ in range(rows):
        amount = round(random.uniform(10, 1000), 2)
        diff = random.choice([0, 0, 0, round(random.uniform(-10, 10), 2)])
        data.append([
            fake.date_this_month().strftime('%Y-%m-%d'),
            f"ORD{fake.unique.random_number(digits=10)}",
            amount,
            amount + diff,
            diff,
            '无' if diff == 0 else random.choice(['佣金差异', '优惠券差异', '运费差异']),
            '平账' if diff == 0 else '未平账'
        ])
    return data

def generate_supplier_info_data(rows):
    data = [['供应商编码', '供应商名称', '资质等级', '联系人', '电话', '邮箱', '结算方式', '账期(天)', '信用额度', '银行账号']]
    for _ in range(rows):
        data.append([
            f"SUP{fake.unique.random_number(digits=6)}",
            fake.company(),
            random.choice(['A级', 'B级', 'C级', 'D级']),
            mask_name(fake.name()),
            mask_phone(fake.phone_number()),
            mask_email(fake.email()),
            random.choice(['月结', '现结', '预付']),
            random.choice([30, 60, 90, 0]),
            random.choice([10000, 50000, 100000, 500000]),
            mask_bank_card(fake.credit_card_number())
        ])
    return data

def generate_inbound_acceptance_data(rows):
    data = [['验收单号', '采购单号', '供应商', '到货日期', '物料名称', '到货数量', '验收数量', '合格数量', '残次数量', '处理意见', '检验员']]
    for _ in range(rows):
        total = random.randint(100, 1000)
        accepted = total
        passed = int(total * random.uniform(0.95, 1.0))
        failed = accepted - passed
        data.append([
            f"ACC{fake.unique.random_number(digits=8)}",
            f"PUR{fake.unique.random_number(digits=8)}",
            fake.company(),
            fake.date_this_year().strftime('%Y-%m-%d'),
            fake.word() + '原料',
            total,
            accepted,
            passed,
            failed,
            '入库' if failed == 0 else '退换货',
            mask_name(fake.name())
        ])
    return data

def generate_supplier_eval_data(rows):
    data = [['评价日期', '供应商名称', '供货批次', '交期评分', '质量评分', '价格评分', '服务评分', '综合得分', '评级']]
    for _ in range(rows):
        s1 = random.randint(60, 100)
        s2 = random.randint(60, 100)
        s3 = random.randint(60, 100)
        s4 = random.randint(60, 100)
        avg = (s1 + s2 + s3 + s4) / 4
        data.append([
            fake.date_this_year().strftime('%Y-%m-%d'),
            fake.company(),
            f"BATCH{fake.random_number(digits=6)}",
            s1, s2, s3, s4,
            f"{avg:.1f}",
            'A' if avg >= 90 else 'B' if avg >= 80 else 'C' if avg >= 60 else 'D'
        ])
    return data

def generate_expense_reimbursement_data(rows):
    data = [['报销单号', '申请人', '部门', '报销日期', '费用类别', '金额', '摘要/用途', '审批状态', '支付日期']]
    for _ in range(rows):
        date = fake.date_this_year()
        status = random.choice(['待审批', '已批准', '已支付', '已驳回'])
        pay_date = (date + datetime.timedelta(days=random.randint(1, 7))).strftime('%Y-%m-%d') if status == '已支付' else ''
        data.append([
            f"EXP{fake.unique.random_number(digits=8)}",
            mask_name(fake.name()),
            random.choice(['销售部', '技术部', '行政部', '财务部']),
            date.strftime('%Y-%m-%d'),
            random.choice(['差旅费', '办公费', '招待费', '交通费', '其他']),
            round(random.uniform(100, 5000), 2),
            fake.sentence(),
            status,
            pay_date
        ])
    return data

def generate_ar_ap_aging_data(rows):
    data = [['单位名称', '类型', '账款总额', '30天内', '30-60天', '60-90天', '90天以上', '逾期金额', '责任人']]
    for _ in range(rows):
        total = round(random.uniform(1000, 100000), 2)
        p1 = round(total * random.uniform(0.1, 0.5), 2)
        p2 = round(total * random.uniform(0, 0.3), 2)
        p3 = round(total * random.uniform(0, 0.1), 2)
        p4 = round(total - p1 - p2 - p3, 2)
        data.append([
            fake.company(),
            random.choice(['应收账款', '应付账款']),
            total,
            p1, p2, p3, p4,
            round(p3 + p4, 2),
            mask_name(fake.name())
        ])
    return data

def generate_cash_flow_data(rows):
    data = [['日期', '账户', '期初余额', '现金流入', '流入说明', '现金流出', '流出说明', '期末余额']]
    balance = 1000000.00
    for _ in range(rows):
        in_amt = round(random.uniform(0, 50000), 2)
        out_amt = round(random.uniform(0, 40000), 2)
        start_bal = balance
        balance = balance + in_amt - out_amt
        data.append([
            fake.date_this_year().strftime('%Y-%m-%d'),
            random.choice(['基本户', '一般户', '支付宝', '微信']),
            round(start_bal, 2),
            in_amt,
            '销售回款' if in_amt > 0 else '',
            out_amt,
            '采购付款/工资' if out_amt > 0 else '',
            round(balance, 2)
        ])
    return data

def generate_crm_followup_data(rows):
    data = [['跟进日期', '客户名称', '联系人', '跟进方式', '沟通内容', '客户意向', '下一步计划', '销售员']]
    for _ in range(rows):
        data.append([
            fake.date_this_month().strftime('%Y-%m-%d'),
            fake.company(),
            mask_name(fake.name()),
            random.choice(['电话', '微信', '拜访', '邮件']),
            fake.sentence(),
            random.choice(['高', '中', '低']),
            random.choice(['发送报价', '预约演示', '合同谈判', '定期回访']),
            mask_name(fake.name())
        ])
    return data

def generate_aftersales_repair_data(rows):
    data = [['服务单号', '客户信息', '产品名称', '购买日期', '故障描述', '服务类型', '处理结果', '费用', '完成日期']]
    for _ in range(rows):
        date = fake.date_this_year()
        finish_date = date + datetime.timedelta(days=random.randint(1, 7))
        data.append([
            f"SRV{fake.unique.random_number(digits=8)}",
            f"{mask_name(fake.name())} {mask_phone(fake.phone_number())}",
            fake.word() + '产品',
            fake.date_between(start_date='-1y', end_date='today').strftime('%Y-%m-%d'),
            fake.sentence(),
            random.choice(['维修', '换货', '退货']),
            random.choice(['维修完成', '已换新', '已退款']),
            round(random.uniform(0, 500), 2),
            finish_date.strftime('%Y-%m-%d')
        ])
    return data

def generate_customer_complaint_data(rows):
    data = [['投诉单号', '投诉日期', '客户名称', '投诉类型', '问题描述', '紧急程度', '处理部门', '处理方案', '客户满意度']]
    for _ in range(rows):
        data.append([
            f"COM{fake.unique.random_number(digits=8)}",
            fake.date_this_year().strftime('%Y-%m-%d'),
            mask_name(fake.name()),
            random.choice(['产品质量', '服务态度', '物流配送', '其他']),
            fake.sentence(),
            random.choice(['一般', '紧急', '非常紧急']),
            random.choice(['客服部', '销售部', '物流部']),
            fake.sentence(),
            random.choice(['满意', '一般', '不满意'])
        ])
    return data

def generate_fixed_asset_data(rows):
    data = [['资产编号', '资产名称', '类别', '规格型号', '购入日期', '原值', '折旧年限', '累计折旧', '净值', '使用部门', '保管人']]
    for _ in range(rows):
        price = round(random.uniform(1000, 100000), 2)
        years = random.randint(3, 10)
        depreciation = round(price * random.uniform(0.1, 0.8), 2)
        data.append([
            f"FA{fake.unique.random_number(digits=6)}",
            fake.word() + '设备',
            random.choice(['电子设备', '运输工具', '办公家具', '机器设备']),
            f"Model-{random.randint(100,999)}",
            fake.date_between(start_date='-5y', end_date='today').strftime('%Y-%m-%d'),
            price,
            years,
            depreciation,
            round(price - depreciation, 2),
            random.choice(['行政部', '财务部', '技术部', '生产部']),
            mask_name(fake.name())
        ])
    return data

def generate_seal_usage_data(rows):
    data = [['申请单号', '申请人', '部门', '用印日期', '印章类型', '文件名称', '文件份数', '用途', '审批人']]
    for _ in range(rows):
        data.append([
            f"SEAL{fake.unique.random_number(digits=8)}",
            mask_name(fake.name()),
            random.choice(['行政部', '财务部', '市场部']),
            fake.date_this_month().strftime('%Y-%m-%d'),
            random.choice(['公章', '合同章', '法人章', '财务章']),
            fake.word() + '合同/文件',
            random.randint(1, 5),
            fake.sentence(),
            mask_name(fake.name())
        ])
    return data

def generate_employee_archive_data(rows):
    data = [['工号', '姓名', '性别', '身份证号', '入职日期', '部门', '岗位', '学历', '毕业院校', '手机号', '状态']]
    for _ in range(rows):
        data.append([
            f"EMP{fake.unique.random_number(digits=5)}",
            mask_name(fake.name()),
            random.choice(['男', '女']),
            mask_id_card(fake.ssn()),
            fake.date_between(start_date='-5y', end_date='today').strftime('%Y-%m-%d'),
            random.choice(['技术部', '销售部', '人事部', '财务部']),
            fake.job(),
            random.choice(['大专', '本科', '硕士', '博士']),
            fake.company() + '大学',
            mask_phone(fake.phone_number()),
            random.choice(['在职', '在职', '在职', '离职'])
        ])
    return data

GENERATORS = {
    'order': generate_order_data,
    'customer': generate_customer_data,
    'finance': generate_finance_data,
    'sales': generate_sales_data,
    'inventory': generate_inventory_data,
    'shipping': generate_shipping_data,
    'attendance': generate_attendance_data,
    'quote': generate_quote_data,
    'purchase': generate_purchase_data,
    'summary': generate_summary_data,
    'raw_material': generate_raw_material_data,
    'production_plan': generate_production_plan_data,
    'material_req': generate_material_req_data,
    'production_track': generate_production_track_data,
    'maintenance': generate_maintenance_data,
    'finished_inspection': generate_finished_inspection_data,
    'piecework_wage': generate_piecework_wage_data,
    'outsourcing': generate_outsourcing_data,
    'ecommerce_inventory': generate_ecommerce_inventory_data,
    'daily_order_summary': generate_daily_order_summary_data,
    'return_refund': generate_return_refund_data,
    'replacement': generate_replacement_data,
    'promotion_review': generate_promotion_review_data,
    'logistics_monitor': generate_logistics_monitor_data,
    'packing_progress': generate_packing_progress_data,
    'ads_data': generate_ads_data,
    'bill_reconciliation': generate_bill_reconciliation_data,
    'supplier_info': generate_supplier_info_data,
    'inbound_acceptance': generate_inbound_acceptance_data,
    'supplier_eval': generate_supplier_eval_data,
    'expense_reimbursement': generate_expense_reimbursement_data,
    'ar_ap_aging': generate_ar_ap_aging_data,
    'cash_flow': generate_cash_flow_data,
    'crm_followup': generate_crm_followup_data,
    'aftersales_repair': generate_aftersales_repair_data,
    'customer_complaint': generate_customer_complaint_data,
    'fixed_asset': generate_fixed_asset_data,
    'seal_usage': generate_seal_usage_data,
    'employee_archive': generate_employee_archive_data,
}

def generate_excel_file(type_key, rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = TYPES.get(type_key, 'Sheet1')
    
    generator_func = GENERATORS.get(type_key)
    if generator_func:
        data = generator_func(rows)
        for row in data:
            ws.append(row)
            
    # Adjust column widths
    for col in ws.columns:
        max_length = 0
        column = col[0].column_letter
        for cell in col:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = (max_length + 2) * 1.2
        ws.column_dimensions[column].width = adjusted_width

    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return output
