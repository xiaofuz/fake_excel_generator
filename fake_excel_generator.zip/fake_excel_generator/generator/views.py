from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.conf import settings  # 新增：导入settings
from .forms import GeneratorForm, MessageForm
from .models import Message
from .utils import generate_excel_file, TYPES
import zipfile
from io import BytesIO
import datetime
import jieba
from collections import Counter
import base64
import os  # 提前导入os，避免重复导入
from wordcloud import WordCloud  # 提前导入WordCloud，更规范
import matplotlib.pyplot as plt
import matplotlib

# 设置matplotlib字体（解决中文显示问题）
matplotlib.rcParams['font.family'] = ['SimHei', 'WenQuanYi Micro Hei', 'Heiti TC']


def index(request):
    # 原index函数代码不变，这里省略（你的index函数是正常的）
    # 处理Excel生成表单
    if request.method == 'POST' and 'generate' in request.POST:
        form = GeneratorForm(request.POST)
        if form.is_valid():
            type_key = form.cleaned_data['type']
            file_count = form.cleaned_data['file_count']
            row_count = form.cleaned_data['row_count']
            type_name = TYPES.get(type_key, 'data')
            timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')

            if file_count == 1:
                # Generate single file
                excel_file = generate_excel_file(type_key, row_count)
                response = HttpResponse(
                    excel_file.read(),
                    content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                )
                filename = f"{type_name}_{timestamp}.xlsx"
                # Encode filename for header compatibility
                try:
                    filename.encode('latin-1')
                except UnicodeEncodeError:
                    # For non-latin filenames (like Chinese), we need URL encoding
                    from django.utils.encoding import escape_uri_path
                    filename = escape_uri_path(filename)
                
                response['Content-Disposition'] = f'attachment; filename="{filename}"'
                return response
            else:
                # Generate multiple files and zip them
                zip_buffer = BytesIO()
                with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                    for i in range(file_count):
                        excel_file = generate_excel_file(type_key, row_count)
                        filename = f"{type_name}_{i+1}_{timestamp}.xlsx"
                        zip_file.writestr(filename, excel_file.read())
                
                zip_buffer.seek(0)
                response = HttpResponse(zip_buffer.read(), content_type='application/zip')
                zip_filename = f"{type_name}_batch_{timestamp}.zip"
                try:
                    zip_filename.encode('latin-1')
                except UnicodeEncodeError:
                    from django.utils.encoding import escape_uri_path
                    zip_filename = escape_uri_path(zip_filename)
                    
                response['Content-Disposition'] = f'attachment; filename="{zip_filename}"'
                return response
    else:
        form = GeneratorForm()
    
    return render(request, 'generator/index.html', {
        'form': form
    })


def needs(request):
    # 处理留言表单
    message_form = MessageForm()
    if request.method == 'POST' and 'message' in request.POST:
        message_form = MessageForm(request.POST)
        if message_form.is_valid():
            # 获取用户IP
            ip_address = request.META.get('REMOTE_ADDR')
            # 检查今天的留言次数
            today = datetime.datetime.now().date()
            message_count = Message.objects.filter(
                ip_address=ip_address,
                created_at__date=today
            ).count()
            
            if message_count < 3:
                # 保存留言
                content = message_form.cleaned_data['content']
                Message.objects.create(
                    content=content,
                    ip_address=ip_address
                )
                # 重定向以防止重复提交
                return redirect('needs')
    
    # 处理点赞
    if request.method == 'POST' and 'like' in request.POST:
        message_id = request.POST.get('message_id')
        # 获取用户已点赞的留言ID列表
        liked_messages = request.session.get('liked_messages', [])
        
        # 检查是否已经点赞过
        if message_id not in liked_messages:
            try:
                message = Message.objects.get(id=message_id)
                message.likes += 1
                message.save()
                # 将点赞的留言ID添加到session中
                liked_messages.append(message_id)
                request.session['liked_messages'] = liked_messages
            except Message.DoesNotExist:
                pass
        return redirect('needs')
        # 处理删除（仅管理员）
    if request.method == 'POST' and 'delete' in request.POST and request.user.is_staff:
        message_id = request.POST.get('message_id')
        try:
            message = Message.objects.get(id=message_id)
            message.delete()
        except Message.DoesNotExist:
            pass
        return redirect('needs')
    
    # 获取所有留言
    messages = Message.objects.all()
    
    # 获取用户已点赞的留言ID列表
    liked_messages = request.session.get('liked_messages', [])
    
    # 生成词云
    wordcloud_image = None
    if messages.exists():
        # 收集所有留言内容
        all_content = ' '.join([msg.content for msg in messages])
        # 使用jieba分词
        words = jieba.cut(all_content)
        # 过滤停用词
        stopwords = set(['的', '了', '和', '是', '在', '有', '我', '他', '她', '它', '们', '这', '那', '你', '您', '请', '要', '能', '可以', '希望', '建议'])
        filtered_words = [word for word in words if word not in stopwords and len(word) > 1]
        # 统计词频
        word_counts = Counter(filtered_words)
        
        if word_counts:
            # 1. 先定义字体路径（关键：避免变量未定义）
            font_path = os.path.join(
                settings.BASE_DIR, 
                'fonts', 
                'AlibabaPuHuiTi-3-45-Light.ttf'  # 确保文件名和实际一致
            )
            
            # 2. 初始化WordCloud（修复语法错误：删除重复的font_path，补全逗号）
            wc = WordCloud(
                width=600,
                height=400,
                background_color='white',
                font_path=font_path  # 唯一的font_path参数，末尾加逗号（可选，但更规范）
            )  # 括号正确闭合
            
            # 生成词云
            wc.generate_from_frequencies(word_counts)
            
            # 保存词云为图片
            buffer = BytesIO()
            wc.to_image().save(buffer, format='PNG')
            buffer.seek(0)
            
            # 转换为base64
            image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
            wordcloud_image = f'data:image/png;base64,{image_base64}'
    
    return render(request, 'generator/needs.html', {
        'message_form': message_form,
        'messages': messages,
        'wordcloud_image': wordcloud_image,
        'liked_messages': liked_messages
    })