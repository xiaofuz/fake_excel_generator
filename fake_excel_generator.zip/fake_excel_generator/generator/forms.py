from django import forms
from .utils import TYPES

class GeneratorForm(forms.Form):
    type = forms.ChoiceField(
        choices=[(k, v) for k, v in TYPES.items()],
        label="Excel类型",
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    file_count = forms.IntegerField(
        min_value=1, 
        max_value=10, 
        initial=1, 
        label="生成文件数量",
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )
    row_count = forms.IntegerField(
        min_value=1, 
        max_value=500, 
        initial=50, 
        label="每个文件的行数",
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )

class MessageForm(forms.Form):
    content = forms.CharField(
        label="留言内容",
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': '请输入您的需求或建议...'})
    )
